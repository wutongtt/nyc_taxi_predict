"""TLC taxi-zone choropleth and Manhattan detail; official projected boundaries."""
import geopandas as gpd
import pandas as pd
import numpy as np
import matplotlib.patheffects as pe
from matplotlib.colors import LogNorm, LinearSegmentedColormap
from matplotlib.patches import Patch
from nyc_plot_style import *

GEO = ROOT / 'data/nyc_tlc_2025/geography/unpacked/taxi_zones/taxi_zones.shp'
shape = gpd.read_file(GEO)
assert shape.crs.to_epsg() == 2263, 'Unexpected boundary projection'
assert shape.LocationID.is_unique, 'Duplicate map zone IDs'
zones = pd.read_csv(DATA / 'zones.csv')
assert set(zones.LocationID) <= set(shape.LocationID), 'Observed zone missing from geometry'
shape = shape.merge(zones[['LocationID', 'orders']], on='LocationID', how='left', validate='one_to_one')
assert int(shape.orders.sum()) == int(zones.orders.sum()), 'Map join changed total orders'
positive = shape.orders.dropna()
norm = LogNorm(vmin=1, vmax=positive.max())
cmap = LinearSegmentedColormap.from_list('blue_volume', ['#F1F6FA', '#C1D9E9', '#6BA8CD', '#2474A5', '#073A66'])
fig, axs = plt.subplots(1, 2, figsize=(9.4, 4.0), layout='constrained', gridspec_kw={'width_ratios': [1.25, 1]})
for ax in axs:
    shape.plot(ax=ax, column='orders', cmap=cmap, norm=norm, linewidth=.18,
               edgecolor='#9BA8B1', missing_kwds={'color':'#E2E4E6','edgecolor':'#9BA8B1'})
    ax.set_axis_off()
# Borough labels use representative points; EWR is shown outside NYC at its true location.
for name in ['Bronx', 'Brooklyn', 'Queens', 'Staten Island']:
    point = shape.loc[shape.borough == name].geometry.union_all().representative_point()
    axs[0].text(point.x, point.y, name, ha='center', va='center', fontsize=8,
                color='#284458', path_effects=[pe.withStroke(linewidth=2.6, foreground='white')])
points = shape.set_index('LocationID').geometry.representative_point()
p = points.loc[161]
axs[0].annotate('Manhattan', (p.x, p.y), xytext=(-56, 25), textcoords='offset points',
                fontsize=8, color='#17354A', arrowprops={'arrowstyle':'-', 'lw':.65, 'color':'#17354A'},
                path_effects=[pe.withStroke(linewidth=2.5, foreground='white')])
for zid, name, offset in [(132, 'JFK Airport', (13,-15)), (1, 'EWR', (-12,12))]:
    p = points.loc[zid]
    axs[0].annotate(name, (p.x, p.y), xytext=offset, textcoords='offset points',
                    fontsize=8, color='#17354A', arrowprops={'arrowstyle':'-', 'lw':.65, 'color':'#17354A'},
                    path_effects=[pe.withStroke(linewidth=2.5, foreground='white')])
# Zoom uses the same projection, boundaries, and color normalization as the overview.
axs[1].set_xlim(974000, 1048000)
axs[1].set_ylim(191000, 262000)
axs[1].text(.02, .97, 'Manhattan detail', transform=axs[1].transAxes, va='top', fontsize=9)
for zid, name, y in [(236, 'Upper East Side N. [236]', .78),
                     (237, 'Upper East Side S. [237]', .65),
                     (230, 'Times Sq / Theatre [230]', .52),
                     (161, 'Midtown Center [161]', .39)]:
    p = points.loc[zid]
    axs[1].plot(p.x, p.y, 'o', ms=2.5, mfc='white', mec='#17354A', mew=.7)
    axs[1].annotate(name, (p.x, p.y), xytext=(.48,y), textcoords='axes fraction',
                    fontsize=7.7, va='center', color='#17354A',
                    arrowprops={'arrowstyle':'-', 'lw':.65, 'color':'#17354A'},
                    path_effects=[pe.withStroke(linewidth=2.8, foreground='white')])
for ax, tag in zip(axs, ['(a)', '(b)']):
    panel(ax, tag)
axs[0].legend(handles=[Patch(facecolor='#E2E4E6', edgecolor='#9BA8B1', label='No retained records')],
              loc='lower left', frameon=False, fontsize=7)
sm = plt.cm.ScalarMappable(norm=norm, cmap=cmap)
cb = fig.colorbar(sm, ax=axs, location='bottom', fraction=.045, pad=.035, shrink=.7,
                  ticks=[1,100,10000,1000000])
cb.ax.set_xticklabels(['1','100','10,000','1,000,000'])
cb.ax.minorticks_off()
cb.set_label('Cumulative pickup orders, Jan–Jun 2025 (log scale)', fontsize=9)
cb.ax.tick_params(labelsize=8)
save(fig, '03_spatial')
print(f'Map verified: {shape.LocationID.nunique()} boundary zones; {len(zones)} observed zones; {int(zones.orders.sum()):,} orders.')

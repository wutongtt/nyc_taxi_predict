"""Publication figures for the two-model NYC hourly experiment."""
import json, glob
from pathlib import Path
import pandas as pd, numpy as np
from nyc_plot_style import *
ROOT=Path(__file__).resolve().parents[1]; RES=ROOT/'output/nyc_tlc_2025'; MODELS=RES/'models'; PROC=RES/'processed'
with open(MODELS/'metrics.json') as f: m=json.load(f)

def readpred(name):
    p=sorted(glob.glob(str(MODELS/f'{name}_test_predictions/part-*.csv')))
    return pd.concat([pd.read_csv(x) for x in p],ignore_index=True)
rf=readpred('RandomForest');gb=readpred('GBT')
# preprocessing: splits and target distribution
spl=pd.read_csv(PROC/'split_summary.csv');dist=pd.read_csv(PROC/'target_distribution.csv')
fig,axs=plt.subplots(1,2,figsize=(9.4,3.0),layout='constrained')
labels=['Train\nJan–Apr','Validation\nMay','Test\nJune']; vals=[]
for n in ['train','validation','test']:
 vals.append(int(spl.loc[spl.split==n,'rows'].iloc[0]))
b=axs[0].bar(range(3),np.array(vals)/1e3,color=[BLUE,ORANGE,GREEN],width=.58)
for x,v in zip(b,vals):axs[0].text(x.get_x()+x.get_width()/2,x.get_height()+10,f'{v/1000:.1f}k',ha='center',fontsize=9)
axs[0].set_xticks(range(3),labels);axs[0].set_ylabel('Hourly samples (thousand)');light_grid(axs[0])
order=['0','1-5','6-20','21-100','>100'];dist['order_bin']=pd.Categorical(dist.order_bin,categories=order,ordered=True);dist=dist.sort_values('order_bin')
axs[1].bar(dist.order_bin,dist['count']/1e3,color=BLUE,width=.62);axs[1].set_xlabel('Observed orders per zone-hour');axs[1].set_ylabel('Training samples (thousand)');light_grid(axs[1])
for ax,tag in zip(axs,['(a)','(b)']):panel(ax,tag)
save(fig,'04_preprocessing')
# model comparison: metrics test
fig,axs=plt.subplots(1,3,figsize=(8.8,2.6),layout='constrained')
for ax,key,label in zip(axs,['mae','rmse','wmape_pct'],['MAE (orders)','RMSE (orders)','WMAPE (%)']):
    vals=[m['test'][name][key] for name in ['RandomForest','GBT']]
    bars=ax.bar([0,1],vals,color=[BLUE,ORANGE],width=.55)
    for bar,v in zip(bars,vals):ax.text(bar.get_x()+bar.get_width()/2,v+max(vals)*.03,f'{v:.2f}',ha='center',fontsize=9)
    ax.set_xticks([0,1],['Random forest','GBT']);ax.set_ylabel(label);ax.set_ylim(0,max(vals)*1.24);light_grid(ax)
save(fig,'05_model_comparison')
# representative traces, selected from train-only ranking
zones=json.loads((PROC/'audit.json').read_text())['representative_zones']
fig,axs=plt.subplots(len(zones),1,figsize=(8.8,5.0),sharex=True,layout='constrained')
if len(zones)==1:axs=[axs]
for ax,z in zip(axs,zones):
    a=rf[rf.pickup_zone==z].copy().sort_values('target_hour').head(168)
    b=gb[gb.pickup_zone==z].copy().sort_values('target_hour').head(168)
    ax.plot(pd.to_datetime(a.target_hour),a.y,color='#222222',lw=1.1,label='Observed' if z==zones[0] else None)
    ax.plot(pd.to_datetime(a.target_hour),a.prediction,color=BLUE,lw=1.0,label='Random forest' if z==zones[0] else None)
    ax.plot(pd.to_datetime(b.target_hour),b.prediction,color=ORANGE,lw=1.0,label='GBT' if z==zones[0] else None)
    ax.set_ylabel(f'Zone {z}\norders');light_grid(ax)
handles, legend_labels = axs[0].get_legend_handles_labels()
fig.legend(handles, legend_labels, frameon=False, ncol=3, loc='outside upper center')
axs[-1].set_xlabel('Test time (June 2025, first 7 days)')
save(fig,'06_prediction_traces')
# feature importance
fig,ax=plt.subplots(figsize=(6.6,3.4),layout='constrained')
features=list(m['test']['RandomForest']['importance']);rfv=[m['test']['RandomForest']['importance'][x] for x in features];gbv=[m['test']['GBT']['importance'][x] for x in features]
order=np.argsort(rfv)[::-1];labels2=[features[i] for i in order];y=np.arange(len(order));ax.barh(y+.18,np.array(rfv)[order],.32,color=BLUE,label='Random forest');ax.barh(y-.18,np.array(gbv)[order],.32,color=ORANGE,label='GBT');ax.set_yticks(y,labels2);ax.invert_yaxis();ax.set_xlabel('Relative feature importance');ax.legend(frameon=False,ncol=2);light_grid(ax,'x');save(fig,'07_feature_importance')
print('RESULT_FIGURES',len(rf),len(gb),zones)

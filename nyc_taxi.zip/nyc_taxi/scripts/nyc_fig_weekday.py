"""Figure 2: average orders, normalized by occurrences of each weekday."""
import numpy as np
import pandas as pd
from matplotlib.colors import LinearSegmentedColormap
from nyc_plot_style import *

d = pd.read_csv(DATA / 'weekday_hour.csv')
d['mean_orders'] = d.orders / d.days
matrix = d.pivot(index='weekday', columns='hour', values='mean_orders').reindex(
    index=range(1, 8), columns=range(24))
assert not matrix.isna().any().any(), 'Incomplete weekday-hour coverage'
fig, axs = plt.subplots(1, 2, figsize=(9.4, 3.05), layout='constrained',
                        gridspec_kw={'width_ratios': [1.25, 1]})
cmap = LinearSegmentedColormap.from_list('print_blue', ['#F4F7FA', '#9CCADD', '#0072B2', '#003D62'])
im = axs[0].imshow(matrix.values / 1000, aspect='auto', cmap=cmap, origin='upper')
axs[0].set_yticks(range(7), ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'])
axs[0].set_xticks(range(0, 24, 3), [f'{h:02d}' for h in range(0, 24, 3)])
axs[0].set_xlabel('Pickup hour (New York local time)')
cb = fig.colorbar(im, ax=axs[0], fraction=.045, pad=.025)
cb.set_label('Mean orders (thousand/hour)', fontsize=9)
for mask, color, label, marker in [(d.weekday <= 5, BLUE, 'Weekdays', 'o'),
                                  (d.weekday >= 6, ORANGE, 'Weekends', 's')]:
    g = d[mask].groupby('hour')[['orders', 'days']].sum()
    axs[1].plot(g.index, g.orders / g.days / 1000, color=color, lw=1.7,
                marker=marker, markevery=3, ms=3.5, label=label)
axs[1].set_xticks(range(0, 24, 3))
axs[1].set_xlabel('Pickup hour (New York local time)')
axs[1].set_ylabel('Mean orders (thousand/hour)')
axs[1].legend(frameon=False)
light_grid(axs[1])
for ax, tag in zip(axs, ['(a)', '(b)']):
    panel(ax, tag)
save(fig, '02_weekday_hour')

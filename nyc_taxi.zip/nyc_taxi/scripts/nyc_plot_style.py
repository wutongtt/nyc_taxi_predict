"""Shared reproducible print style for the NYC dataset figures."""
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'output/nyc_tlc_2025/dataset'
FIG = ROOT / 'output/nyc_tlc_2025/figures'
FIG.mkdir(parents=True, exist_ok=True)
BLUE = '#0072B2'
ORANGE = '#D55E00'
GREEN = '#009E73'
GRAY = '#7A7A7A'
plt.rcParams.update({
    'font.family': 'serif', 'font.serif': ['DejaVu Serif'],
    'font.size': 10, 'axes.labelsize': 10, 'xtick.labelsize': 9,
    'ytick.labelsize': 9, 'legend.fontsize': 9,
    'axes.spines.top': False, 'axes.spines.right': False,
    'axes.edgecolor': '#555555', 'axes.linewidth': .7,
    'pdf.fonttype': 42, 'ps.fonttype': 42,
    'savefig.dpi': 300, 'savefig.bbox': 'tight', 'savefig.pad_inches': .08})


def save(fig, name):
    for ext in ('pdf', 'png'):
        fig.savefig(FIG / (name + '.' + ext), dpi=300)
    plt.close(fig)


def panel(ax, text):
    ax.text(0, 1.04, text, transform=ax.transAxes, fontweight='bold')


def light_grid(ax, axis='y'):
    ax.grid(axis=axis, color='#D9DDE2', linewidth=.55)
    ax.set_axisbelow(True)


def profile():
    return json.loads((DATA / 'profile.json').read_text())

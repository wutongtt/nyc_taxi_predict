"""Validation-selected RF/GBT, refit through May, one June batch backtest."""
import json,time,math
from pathlib import Path
from pyspark import StorageLevel
from pyspark.sql import SparkSession,functions as F
from pyspark.ml import PipelineModel
from pyspark.ml.feature import StringIndexer,VectorAssembler
from pyspark.ml.regression import RandomForestRegressor,GBTRegressor

OUT=Path('/work/output/nyc_tlc_2025/models');OUT.mkdir(parents=True,exist_ok=True)
H='hdfs://hadoop:9000/data/nyc_tlc_2025'
spark=(SparkSession.builder.appName('nyc-rf-gbt-validation-and-test').config('spark.sql.session.timeZone','America/New_York').config('spark.sql.shuffle.partitions','32').getOrCreate())
spark.sparkContext.setLogLevel('WARN')
base=spark.read.parquet(f'{H}/dws/samples').withColumn('zone_key',F.col('pickup_zone').cast('string'))
train=base.filter(F.col('split')=='train');val=base.filter(F.col('split')=='validation');test=base.filter(F.col('split')=='test')
idx=StringIndexer(inputCol='zone_key',outputCol='zone_index',stringOrderType='alphabetAsc',handleInvalid='error').fit(train)
features=['hour','weekday','is_weekend','lag_1','lag_24','lag_168','roll_24','roll_168','zone_index']
assembler=VectorAssembler(inputCols=features,outputCol='features')
def vectorize(df):return assembler.transform(idx.transform(df)).select('features','y','pickup_zone','hour_ts','date','hour','weekday','split')
tr=vectorize(train).repartition(16).persist(StorageLevel.MEMORY_AND_DISK)
va=vectorize(val).persist(StorageLevel.MEMORY_AND_DISK)
counts={'train':tr.count(),'validation':va.count(),'test':test.count()}
maxbins=max(64,len(idx.labels))
configs={'RandomForest':[{'numTrees':30,'maxDepth':8},{'numTrees':30,'maxDepth':10}],
         'GBT':[{'maxIter':30,'maxDepth':4,'stepSize':.1},{'maxIter':30,'maxDepth':6,'stepSize':.1}]}
result={'counts':counts,'features':features,'seed':2026,'maxBins':maxbins,'validation':{},'test':{},'selection':'Minimum validation WMAPE; two predeclared configurations per family; refit Jan-May; evaluate June once.','prediction':'Rolling one-hour-ahead, fixed models, batched test; true prior observed hourly counts available.','negative_predictions_policy':'Raw model outputs retained without clipping or rounding.'}
def checkpoint():(OUT/'metrics.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
def estimator(name,params):
    common=dict(labelCol='y',featuresCol='features',maxBins=maxbins,seed=2026)
    if name=='RandomForest':return RandomForestRegressor(**common,**params,featureSubsetStrategy='onethird',subsamplingRate=1.)
    return GBTRegressor(**common,**params,lossType='squared',subsamplingRate=1.)
def metrics(pred):
    delta=F.col('prediction')-F.col('y')
    r=pred.agg(F.count('*').alias('n'),F.sum(F.abs(delta)).alias('absolute_error'),F.sum(delta*delta).alias('squared_error'),F.sum('y').alias('true_orders'),F.sum(delta).alias('signed_error'),F.sum((F.col('prediction')<0).cast('long')).alias('negative_predictions')).first().asDict()
    r.update(mae=r['absolute_error']/r['n'],rmse=math.sqrt(r['squared_error']/r['n']),wmape_pct=100*r['absolute_error']/r['true_orders'],bias_pct=100*r['signed_error']/r['true_orders'])
    return r
for name,choices in configs.items():
    result['validation'][name]=[]
    for params in choices:
        print('FIT_VALIDATION',name,params,flush=True);t=time.time()
        model=estimator(name,params).fit(tr);fitsec=time.time()-t
        m=metrics(model.transform(va));m.update(params=params,fit_seconds=fitsec)
        result['validation'][name].append(m);checkpoint();print('VALIDATION_DONE',name,json.dumps(m),flush=True)
tr.unpersist();va.unpersist()
refit=vectorize(base.filter(F.col('split')!='test')).repartition(16).persist(StorageLevel.MEMORY_AND_DISK)
te=vectorize(test).persist(StorageLevel.MEMORY_AND_DISK)
result['refit_rows']=refit.count();te.count()
for name in configs:
    best=min(result['validation'][name],key=lambda x:x['wmape_pct'])
    print('REFIT',name,best['params'],flush=True);t=time.time()
    model=estimator(name,best['params']).fit(refit);fitsec=time.time()-t
    # Save a pipeline accepting raw sample columns. StringIndexer is fixed on Jan-Apr zones.
    PipelineModel(stages=[idx,assembler,model]).write().overwrite().save(f'file://{OUT}/{name}')
    pred=model.transform(te).persist(StorageLevel.MEMORY_AND_DISK)
    result['test'][name]=metrics(pred);result['test'][name].update(params=best['params'],refit_seconds=fitsec)
    result['test'][name]['importance']={k:float(v) for k,v in zip(features,model.featureImportances.toArray())}
    (pred.select('pickup_zone',F.date_format('hour_ts','yyyy-MM-dd HH:mm:ss').alias('target_hour'),'date','hour','weekday','y','prediction').coalesce(4).write.mode('overwrite').option('header',True).csv(f'file://{OUT}/{name}_test_predictions'))
    # Reload persisted model and validate prediction equivalence on a fixed small test slice.
    probe=test.orderBy('pickup_zone','hour_ts').limit(200)
    a=PipelineModel(stages=[idx,assembler,model]).transform(probe).select('pickup_zone','hour_ts',F.col('prediction').alias('a'))
    b=PipelineModel.load(f'file://{OUT}/{name}').transform(probe).select('pickup_zone','hour_ts',F.col('prediction').alias('b'))
    err=a.join(b,['pickup_zone','hour_ts']).agg(F.max(F.abs(F.col('a')-F.col('b')))).first()[0]
    assert err==0.,('reload mismatch',name,err)
    result['test'][name]['reload_max_abs_diff']=err
    pred.unpersist();checkpoint();print('TEST_DONE',name,json.dumps(result['test'][name]),flush=True)
refit.unpersist();te.unpersist();spark.stop();print('MODELS_COMPLETE',flush=True)
